# Revisions

## Notes

### Isotopomer papers

* wiechert-wolfgang-1999.pdf (part 3):
    * Each isotopomer requires its own isotopomer fraction balance equation.
    * References Schmidt et al (1997) and Zupke/Stephanopoulos (1994) for the atom mapping matrices to model the positional carbon labelling.
    * References Wiechert (1996) for the transition matrix approach.

* weitzel-michael-2007.pdf:
    * Simulating isotopomer labelling experiments to deduce reaction fluxes.
    * Basically MFA.
    * General procedure:
        * Set up flux-balance equations for each metabolite.
        * Derive the isotopomer labelling network (ILN).
        * Set up the isotopomer balance equations (IBEs) that relate the labelling of each compound to the reactions and participating labelled substrate/product isotopomers.
        * Cumomers are cumulative sets of isotopomers.
        * IBEs are converted to CBEs which do not involve any splitting reactions in the isotopomer mass conservation equations.
        * The number of cumomers is equal to the number of isotopomers.
    * The isotopomer network nor cumomer network is not equal to the atomic transition graph proposed in my work.
        * Both isotopomer and cumomer network represent all of the labelling states on a single network.
        * The isotopomer network allows for splitting reactions (hypergraph).
        * The cumomer network removes these splitting reactions but still represents a set of isotopomer labelling states.
        * The atomic transition graph is identical to pitkanen-esa-2009/heath-allison-2010/2011/pey-jon-2012/2014

* mack-sean-2021.pdf
    * Simulates isotopomer data.
    * Calculates the fraction of carbons that are transferred between pairs of metabolites.
    * Can be used to isolate carbon flows involving sources and targets of interest.
    * Does not tell you how individual carbon atoms move through the network unless one iteratively labels a single carbon.
    * Definitely does not take into account reaction directionalities and the presence of internal cycles. (The cycling bit is the most important).

### Atom mapping and metabolic pathways

* Lots of graph theory!

* arita-masanori-2000.pdf:
    * First method to discuss metabolite-atom graphs.
    * AMR method (automated metabolic re-construction).
    * Metabolic graph denotes nodes corresponding to atoms and edges their
      enzymatic mappings.
    * Traversals explored by $K$-shortest pathway algorithms.
    * Focused on traversal of a carbon source to a target metabolite.
    * Did not distinguish between pathways that could transfer more carbon atoms over others.
    * Could not deal with branching pathways.
* wagner-andreas-2001.pdf:
    * Seminal paper that showed that when constructing metabolite graphs
      (nodes are metabolites and edges correspond to substrate-product
      relationships from enzymes), many pathways traversed pool
      metabolites (co-factors).
    * Cited in atom-mapping and atomic pathway literature to highlight the benefit of incorporating atom-mapping information into metabolic pathways.
    * Otherwise many pathways are meaningless (false positives) in the sense that the pathway does not actually convert the substrate into the co-factor and then transform that into a completely different downstream product.
    * Could not deal with branching pathways.

* arita-masanori-2003.pdf:
    * Extended work to metabolite-atom graphs.
    * $K$-shortest pathway.

* mcshan-d-2003.pdf:
    * Similar to rahman-s-2005.
    * Uses chemical similarity to constrain pathway predictions from atom mappings.
* rahman-s-2005.pdf:
    * Metabolic pathways from atom mapping data.
    * Pathway Hunter Tool (PHT).
    * $K$-shortest pathways.
    * Weighted scores based on structural similarity (Tanimoto Coefficient) and atomic mass contribution in each reaction.
    * Structural similarity is used to avoid assigning pathways involving pool metabolites (since the substrate doesn't structurally resemble the co-factor).
    * Could not deal with branching pathways.

* croes-didier-2006.pdf:
    * Constructs metabolite graph.
    * Uses metabolite node degree as a weight to avoid pathways that traverse pool metabolites.
    * Could not deal with branching pathways.

* blum-torsten-2008.pdf:
    * Tool that uses atom mapping rules to define feasible pathways transferring atoms from source to sink and visualising the paths on the molecular metabolic bipartite graph.
    * MetaRoute name.
    * Could not deal with branching pathways.

* defigueiredo-luis-2009.pdf:
    * Case study analysis of graph-theoretic and EFM analysis for metabolic pathway analysis.
    * Comment that the graph theory approaches can identify unbalanced pathways that are not biologically feasible under steady state.
        * Potential rebuttal in pitkanen-esa-2009 that these unbalanced pathways could potentially reveal exchange fluxes.
        * Counterargument (from me) that if the network is well-defined (as many good models are these days), the unbalanced pathways are less likely to be biologically real.
    * Comment that graph theory approaches of the time neglect stoichiometric constraints too.
    * Also a comment that graph theory approaches do not explicitly look for cycles.
    * At the molecular level, cycles do occur in biology (TCA, urea, etc.)
    * My opinion: it is also known that some futile cycles do occur in biology (thermogenesis). Backed up by sharma-anand-2024 (at least in complex eukaryotic systems like humans)

* pitkanen-esa-2009.pdf:
    * Summarises the papers above (arita to blum).
    * ReTrace is the software/algorithm name.
    * Searches for pathways at the atom level
    * Works on branching pathways and finds the ones that transfer as many atoms from source to target.
    * Benefit that operating at the atom level eliminates the pool metabolite problem.
    * Similar to other works (blum-torsten-2008), it also visualises the atomic pathways back onto the metabolites.
    * Can handle cycles and branches.
    * Uses heuristics to identify pathways that conserve more than one atom throughout the pathway.
    * Mentions EFMs for some reason. Specifically, they talk about the defigueiredo-luis-2009 paper and some counterarguments for why metabolic graph approaches are still useful (which they are!)

* heath-allison-2010.pdf and heath-allison-2011.pdf:
    * LPAT is the name. Metabolic pathways from atom mapping.
    * Both linear and branching pathways involving a source and target compound.
    * Constrained by minimum number of conserved atoms and maximum pathway length.
    * Does not deal with cycles in the algorithm.

* latendresse-mario-2014.pdf
    * RouteSearch is the name.
    * Multiple optimal criteria such as number of non-native reactions, number of atoms lost from start to target, maximum pathway length, etc.
    * First algorithm that guarantees optimal paths under these criteria.

* huang-yiran-2017.pdf:
    * Metabolic pathways but with atomic subgroups.
    * AGPathFinder is the name.
    * Basically intermediate resolution between individual atoms and standard metabolite hypergraphs.
    * $K$-shortest pathways.
    * Avoids atom mapping data since it relies on structural similarity and reaction thermodynamics to determine the atomic subgroups that are transferred.
    * Also determines paths from source to target.

* kim-sarah-2020.pdf
    * Hub pathway search with atom tracking (HPAT) is the name.
    * Combines other algorithms described above.
    * Feature is that it can condense pathways into those that involve hub metabolites (which are not defined but appear to be shared compounds that appear in my pathways involving a given pair of sources and targets).

* pey-jon-2011.pdf:
    * Elementary carbon mode (ECM).
    * Idea of defining EFMs with respect to individual atoms.
    * Simple paths or simple cycles.
    * Their example showed a greater number of ECMs than EFMs in small networks.
    * However, they did not address whether this observation held empirically in large-scale networks.
    * Did not address the EFM/ECM flux decomposition problem.
    * Carbon flux modes were not defined at the atomic level.

* pey-jon-2012.pdf:
    * Elementary carbon modes (ECMs) but confusingly at the atomic level.
    * Also simple paths/simple cycles.
    * They define the continuity constraint as the relationship between metabolic flux equalling the the underlying flux at the carbon (atomic) level.
    * Their example showed a greater number of ECMs than EFMs in small networks.
    * However, they did not address whether this observation held empirically in large-scale networks.
    * Did not address the EFM/ECM flux decomposition problem.
    * Simulated random EFM weights, then simulated the steady state isotopomer distributions and attempted to calculate the ECM weights to reconstruct the EFM weights. Their results failed on the cycles because of the underdetermined nature of the flux system.

* pey-jon-2014.pdf:
    * Redefines the ECM as the CFP at the atomic level (aCFP).
    * Integer programming approach to compute $K$-shortest pathways.
    * aCFPs here are only simple paths (no internal cycles are calculated).

* tervo-christopher-2016.pdf:
    * MapMaker and PathTracer are the names.
    * Heuristics!
    * MapMaker identifies elemental transfers which is the number of carbons transferred (not necessarily atomic positions like pey-jon-2014).
    * PathTracer identifies paths but based on carbon transfer (and not individual carbons moving from substrate to product).
    * Can be used to enumerate the $k$-shortest pathways OR identify the most activity pathway between source and target carrying the greatest amount of steady state flux.
    * Can also identify cycles but not branches.

* hafner-jasmin-2021.pdf:
    * Nicepath.
    * For de novo pathway discovery.
    * Uses atom mapping and enzymatic reaction rules.

## Summary of literature above

* Different notions of network/graph representations:
    1. Metabolic network (directed/undirected hypergraph or bipartite graph):
        * Metabolite nodes and reaction edges (or reaction nodes).
        * Probably just draw a directed hypergraph.
        * Example of bipartite graph: patil-kiran-2007
        * Best example is lacroix-v-2008 for all three.
        * Also include noack-stephan-2007! (extended bipartite)
    2. Metabolic graph (directed or undirected graph):
        * Metabolite nodes connected to each other by known reactions.
        * arita-masanori-2000 (directed).
        * jeong-h-2000 (directed).
        * hongwu-ma-2003 (directed).
        * wagner-andreas-2001 (undirected).
        * arita-masanori-2004 (undirected).
    3. Element exchange graph (directed graph):
        * Metabolite nodes but edges correspond to substrates and products that exchange a given atom type.
        * pey-jon-2011
        * tervo-christopher-2016
    4. Atom transition network (directed graph):
        * Metabolite nodes but edges correspond to exact atom mappings from substrate to product.
        * pitkanen-esa-2009
        * heath-allison-2010/heath-allison-2011
        * pey-jon-2012
    5. Isotopomer network (weitzel-michael-2007)
        * Metabolite isotopomer nodes and reaction edges interconverting to different isotopomers.
    6. Cumomer network (weitzel-michael-2007)
        * Metabolite cumomer nodes and reaction edges (including new ones to a virtual sink pool)
    * Imagine drawing these 5 representations above.

* Different notions of pathway in these representations:
    * Discussed by defigueiredo-luis-2009 and pitkanen-esa-2009.
    * EFM in a metabolic network (directed hypergraph).
    * Simple path and/or simple cycle at the metabolite/atomic level in metabolic graphs.
    * Branching pathway at the metabolite/atomic level in metabolic graphs.
    * Little mention of branching cycles (aside from EFMs).

* Analysis of these pathways with respect to the EFM flux decomposition problem.
    * EFMs in metabolic networks:
        * Enumeration scalability and decomposition ambiguity
    * Metabolic graphs by metabolites:
        * Not concerned with explaining pathway fluxes.
        * Only applicable to simple paths (no branching or cycles.)
        * Pool metabolite problem (false pathways)
        * $K$-shortest pathways.
    * Metabolic graphs by atoms:
        * Some only operate on carbons.
        * Some use atom mapping predictions/data.
        * Some atom mapping data is used qualitatively (carbon transfer only).
        * Some can deal with branching pathways and/or cycles (pitkanen-esa-2009, tervo-christopher-2016).
        * A single one identifies pathways based on the capacity to carry the greatest steady state flux from source to target (tervo-christopher-2016)
        * $K$-shortest pathways.
    * Pey atomic (carbon) flux path.
        * Only worked for tracing compounds.
        * Also came up with the idea of EFMs being applied to carbon atom level.
        * $K$-shortest pathways.
        * Does not handle cycles. (Branches don't exist.)
    * Isotopomer/cumomor networks:
        * weitzel-michael-2007

## Introduction

1. Metabolic graph (metabolite nodes connected to each other based on
   substrate-product reaction relationships).

2. Elemental transfer graph (a metabolic graph above but the same element
   must be present in the substrate-product pair).

3. Atom transition graph (we do this and will cite the people who came up
   with this idea before us).

4. Isotopomer network (graphical representation of isotopomer balance
   equations in a metabolic network.

5. Cumomer network (graphical representation of cumulative isotopomer
   balance equations in a balance network)

In parallel with EFM analysis, the problem of identifying metabolic
pathways has also been approached by graph-theoretical methods. These
methods use different structural properties of metabolic flux networks to
graphically represent the relationship between distinct metabolites. The
earliest representation, for example, is the metabolic graph
(arita-masanori-2000, wagner-andreas-2001)


The earliest representation is the metabolic graph (arita-masanori-2000,
wagner-andreas-2001) where metabolite nodes are connected to each other
based on substrate-product reaction relationships. Both methods could
calculate metabolic pathways defined as simple paths between source and
target metabolites. However, these methods often returned biologically
meaningless pathways due to the presence of pool metabolites. Subsequent
groups incorporated heuristics to avoid these pathways involving pool
metabolites based on chemical similarity and node degree distribution
(mcshan-d-2003,rahman-s-2005,croes-didier-2006). These heuristics were
superseded by elemental transfer graphs, whereby edges were only assigned
to substrate-product pairs that contained the same element (typically
carbon) transferred from one metabolite to another.


, which constrained metabolite pairs to substrates and products 

metabolite pairs by the presence of the same atom type (typically carbon)
(pey-jon-2011/ tervo-christopher-2016).




represents the relationship between metabolite nodes participating in
metabolic reactions. Linear routes between source and target metabolites
could be computed via $K$-shortest pathway algorithms; however, these
methods often returned biologically meaningless pathways due to reactions
involving pool metabolites (ATP, ADP, NADH, etc.). 



With the availability of atom mapping data, these heuristics were replaced
by elemental transfer graphs, whereby metabolite nodes were only connected
if a given element (usually carbon) was transferred between them
(pey-jon-2011, tervo-christopher-2016). The natural extension of these
graphs are atom transition graphs which denote the movement of each atom
from substrate to product in a reaction (arita-masanori-2003). Follow-up
methods to analyse these graphs were extended to identify $K$-shortest
branching pathways and cyclic pathways (blum-torsten-2008,
pitkanen-esa-2009, heath-allison-2010, heath-allison-2011,
latendresse-mario-2014, kim-sarah-2020). These atom transition graphs are
related to isotopomer and cumomer networks which represent the
mass-balance equations of all isotopomers and cumomers in a metabolic
network (wiechert-1999, weitzel-michael-2007). Analysis of these networks
is critical for inferring reaction fluxes from isotope labelling
experiments in metabolic flux analysis.

Aside from EFM analysis of standard metabolic flux networks, very few of
them are suited for inferring the distribution of steady state pathway
fluxes in a metabolic flux network. Metabolic graphs (with/without atom
mapping data) do not capture reaction stoichiometry
(defigueiredo-luis-2009) with existing methods only capable of identify
simple paths carrying the maximal flux between source and target
metabolites (tervo-christopher-2016). Current methods to analyse atom
transition graphs remain limited to $K$-shortest simple paths, branching
paths, or simple cycles. These graphs often fail to account for reaction
stoichiometry and steady state fluxes. While these properties are
addressed in isotopomer and cumomer networks, these graphical
representations are designed to identify the set of reaction fluxes
consistent with isotope labelling experiments and cannot 

and not the set of pathway fluxes explaining these 

y do not explain the concerted flow of atoms through the network from
source to target metabolites.

This very problem was addressed by Pey et al. (2011)


(2011/2012/2014)


Now a section on Pey's work (2011, 2012, 2014).

A notable limitation of Pey's work was their inability to assign


not routes were biologically which were subsequently extended to branching
pathways and simple cycles. 

In parallel with EFM analysis are a plethora of other network and graph
representations to analyse metabolic flux networks.


## Results

## Methods

* Isotopomer comment: Just remove.
    * Defined as the $2^n$ labelling states of a given molecule (where $n$ is the number of carbons of interest or some other element).

## Limitations

* 

## Figure modifications

* Pipeline step 3: "ACHMC" and not "Atomic ACHMC"
